# GPT Translator Bot

Телеграм-бот, который:
- Распознаёт текст с картинок (OCR)
- Переводит текст с английского на русский через GPT-4
- Работает через Telegram

## Установка

1. Установите зависимости:
```
pip install -r requirements.txt
```

2. Создайте `.env` файл по примеру `.env.example` и вставьте туда свои ключи.

3. Запустите бота:
```
python bot.py
```

## Требования
- Python 3.10+
- Tesseract OCR: `sudo apt install tesseract-ocr`